const passport = require('passport');
const mongoose = require('mongoose');
const User = require('../models/user');

// -------------------------------------------------
// Register-Create a new user account and return JWT
// -------------------------------------------------
const register = async (req, res) => {
    // Validate input to insure that all parameters are present
    if (!req.body.name || !req.body.email || !req.body.password) {
        return res
            .status(400)
            .json({ "message": "All fields required" });
    }

    // Create a new user account
    const user = new User(
        {
            name: req.body.name,            // Set User name
            email: req.body.email,          // Set e-mail address
            password: '',                   // Start with empty password
            role: req.body.role || 'user'   // Admin account can be created if sent in body
        });
    user.setPassword(req.body.password)     // Set user password

    try {
        const q = await user.save();
        // Return new user token
        const token = user.generateJWT();  // Generate JWT Token
        return res.status(200).json(token);
    } catch (err) {
        // Database returned no data
        return res.status(400).json(err);
    }
};

// -------------------------------------------------------
// Login-Authenticate existing user account and return JWT
// -------------------------------------------------------
const login = (req, res) => {
    // Validate message to ensure that email and password are present.
    if (!req.body.email || !req.body.password) {
        return res.status(400).json({ "message": "All fields required" });
    }

    // Use Passport authentication local strategy 
    passport.authenticate('local', (err, user, info) => {
        // Error in Authentication Process
        if (err) {
            return res.status(404).json(err);
        }

        if (user) { // Auth succeeded - generate JWT and return to caller
            const token = user.generateJWT();
            res.status(200).json({ token });
        } else { // Auth failed return error
            res.status(401).json(info);
        }
    })(req, res);
};

// Export methods that drive endpoints.
module.exports = {
    register,
    login
};

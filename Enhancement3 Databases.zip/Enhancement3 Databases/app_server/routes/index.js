const express = require("express"); // Express app
const router = express.Router();    // Router logic
const jwt = require('jsonwebtoken'); // Enable JSON Web Tokens


// This is where we import the controllers we will route
const tripsController = require("../controllers/trips");
const authController = require("../controllers/authentication");
const checkRole = require('../middleware/checkRole');   // Using middleware role in route

// ---------------------------------------
// Middleware for JWT Authentication
// ---------------------------------------

// Method to authenticate our JWT
function authenticateJWT(req, res, next) {
    // console.log('In Middleware');

    const authHeader = req.headers['authorization'];
    // console.log('Auth Header: ' + authHeader);

    if (!authHeader) {
        console.log('Auth Header Required but NOT PRESENT!');
        return res.sendStatus(401);
    }

    let headers = authHeader.split(' ');
    if (headers.length < 1) {
        console.log('Not enough tokens in Auth Header: ' + headers.length);
        return res.sendStatus(501);
    }

    const token = authHeader.split(' ')[1];
    // console.log('Token: ' + token);

    if (!token) {
        console.log('Null Bearer Token');
        return res.sendStatus(401);
    }

    // console.log(process.env.JWT_SECRET);
    // console.log(jwt.decode(token));
    const verified = jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
        if (err) {
            return res.sendStatus(401).json('Token Validation Error!');
        }
        req.auth = verified; // Set the auth paramto the decoded object
    });
    next(); // We need to continue or this will hang forever
}

// -------------------------------
// Routes
// -------------------------------

// Define route for login endpoint
router
    .route('/login')
    .post(authController.login);

// Define route for registeration endpoint 
router
    .route("/register")
    .post(authController.register);

// Define route for our trips endpoint
router
    .route("/trips")
    .get(tripsController.tripsList) // GET Method routes tripsList
    .post(authenticateJWT, checkRole('admin'), tripsController.tripsAddTrip); //POST Method Adds a Trip, only admin

// GET Method routes tripsFindByCode - requires parameter
// PUT Method routes tripsUpdateTrip - requires parameter
router
    .route("/trips/:tripCode")
    .get(tripsController.tripsFindByCode) // GET Method routes tripsFindByCode
    .put(authenticateJWT, checkRole('admin'), tripsController.tripsUpdateTrip); // PUT Method to Update a trip, only admin

module.exports = router;
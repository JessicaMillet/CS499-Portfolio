// API endpoint to get trips
const tripsEndpoint = "http://localhost:5000/api/trips"; // Updated backend port
const options = { method: "GET", headers: { Accept: "application/json" } };
//var fs = require('fs');
//var trips = JSON.parse(fs.readFileSync('./data/trips.json','utf8'));

// ----------------------------------------------------------------------------------------
// Enhancement: large async fetch is split into a helper function for clearer understanding
// ----------------------------------------------------------------------------------------

// Helper function-fetch trips from API
async function fetchTrips() {
    const response = await fetch(tripsEndpoint, options);
    const json = await response.json();

    let message = null;

    // Check for API response that includes an array or empty array
    if (!(json instanceof Array)) {
        message = "API lookup error";
        return { trips: [], message };
    } else if (!json.length) {
        message = "No trips exist in our database!";
    }

    return { trips: json, message };
}

// ---------------------------------------------------------------------------------
// Travel controller-fetchs trips from API and displays travel page
// ---------------------------------------------------------------------------------
/* GET travel view through travel controller */
const travel = async function (req, res, next) {
    // console.log('TRAVEL CONTROLLER BEGIN');
    try {
        // Helper function is used to get trips and message
        const { trips, message } = await fetchTrips();

        // console.log(trips);
        // The travel page gets displayed with fetched data
        res.render("travel", { title: "Travlr Getaways", trips, message });
    } catch (err) {
        // Error handling from fetch
        res.status(500).send(err.message);
    }
};

module.exports = {
    travel,
};
const mongoose = require('mongoose');
const Trip = require('../models/travlr'); // Register model
const Model = mongoose.model('trips');


// Helper function to create a Set of all trip codes for quicker lookup (Enhancement for Algorithms and Data Structures)
async function getAllTripCodes() {
    const trips = await Model.find({}).exec();
    return new Set(trips.map(trip => trip.code));
}

// Helper function to reduce repetition and make updates more maintainable without manually updating
function updateTripFields(tripData, fields) {
    for (const key in fields) {
        if (fields.hasOwnProperty(key) && key !== "_id") {     // to skip the id
            tripData[key] = fields[key];
        }
    }
}

// GET: /trips - lists all the trips 
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsList = async (req, res) => {
    const q = await Model
        .find({}) // No filter, return all records
        .exec();

    // Uncomment the following line to show results of query
    // on the console
    console.log(q);

    if (!q) { // Database returned no data
        return res
            .status(404)
            .json({ message: "Trips not found" });
    } else { // Return resulting trip list
        return res
            .status(200)
            .json(q);
    }
};

// GET: /trips/:tripCode - lists a single trip 
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsFindByCode = async (req, res) => {
    const tripCodes = await getAllTripCodes();

    if (!tripCodes.has(req.params.tripCode)) {
        // Code does not exist in the database
        return res.status(404).json({ message: "Trip not found" });
    }

    // Fetch for the trip because the trip exists
    const q = await Model
        .findOne({ 'code': req.params.tripCode }) // Return single record
        .exec();

    // Uncomment the following line to show results of query
    // on the console
    console.log(q);

    return res
        .status(200)
        .json(q);
};

// POST: /trips - Adds a new Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsAddTrip = async (req, res) => {
    const newTrip = new Trip({
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description
    });

    try {
        const q = await newTrip.save();
        // Uncomment the following line to show results of operation
        // on the console
        console.log(q);
        // Database returned no trip
        return res.status(201).json(q);
    } catch (err) {
        // Database returned no data
        return res.status(400).json({ message: err.message });
    }
};

// PUT: /trips/:tripCode - Adds a new Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsUpdateTrip = async (req, res) => {

    // Uncomment for debugging
    console.log(req.params);
    console.log(req.body);

    // The first step is to find the trip 
    const trip = await Model.findOne({ 'code': req.params.tripCode }).exec();

    if (!trip) {
        // Database returned no data
        return res.status(404).json({ message: "Trip not found" });
    }

    // Helper function to update fields
    updateTripFields(trip, req.body);

    // Updated trip is saved
    const updatedTrip = await trip.save();
    console.log(updatedTrip);

    // Return resulting updated trip
    return res.status(200).json(updatedTrip);

    // Uncomment the following line to show results of operation
    // on the console
    // console.log(q);
};


module.exports = {
    tripsList,
    tripsFindByCode, // Added additional endpoint to module.exports
    tripsAddTrip,
    tripsUpdateTrip
};